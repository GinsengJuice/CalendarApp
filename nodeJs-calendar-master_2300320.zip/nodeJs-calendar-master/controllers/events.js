const { response } = require('express');
const Evento = require('../models/Evento');
const CalendarShare = require('../models/CalendarShare'); 
const CalendarCategory = require('../models/CalendarCategory'); 

const getEventos = async( req, res = response ) => {
    // 현재 사용자 ID
    const currentUserId = req.uid;

    try {
        // 1. 현재 사용자가 소유한 모든 캘린더 ID를 찾습니다.
        const ownedCalendars = await CalendarCategory.find({ user: currentUserId }, '_id');
        const ownedCalendarIds = ownedCalendars.map(cat => cat._id); // A가 소유한 캘린더 ID 목록

        // 2. 현재 사용자가 공유받은 모든 캘린더 ID를 찾습니다.
        const sharedEntries = await CalendarShare.find({ user: currentUserId });
        const sharedCalendarIds = sharedEntries.map(entry => entry.calendar); // A가 공유받은 캘린더 ID 목록

        // 3. 조회할 모든 캘린더 ID를 통합합니다. (중복 제거를 위해 Set을 사용)
        const allRelevantCalendarIds = [...new Set([
            ...ownedCalendarIds, 
            ...sharedCalendarIds
        ])];

        // 4. 통합된 캘린더 ID 목록에 속한 모든 이벤트를 조회합니다.
        const events = await Evento.find({
            // ✨ 조회 조건: 이벤트의 calendarId가 소유하거나 공유받은 ID 목록 중 하나에 속해야 함
            calendarId: { $in: allRelevantCalendarIds }
        })
        .populate('user','name'); 

        res.json({
            ok: true,
            eventos: events 
        });

    } catch (error) {
        console.log(error);
        res.status(500).json({
            ok: false,
            msg: '이벤트 조회 중 서버 오류가 발생했습니다.'
        });
    }
}


const crearEvento = async( req, res = response ) => {    
   
    const { user: reqUser, ...eventData } = req.body; 
    
    const evento = new Evento(eventData); // user 필드가 제거된 깨끗한 데이터로 객체 생성

    try {
        //  JWT 토큰에서 가져온 유효한 ID로 user 필드를 덮어쓰기
        evento.user = req.uid;
        
        const eventoGuardado = await evento.save();

        res.json({
            ok: true,
            evento: eventoGuardado
        })

    } catch (error) {
        console.log(error)
        res.status(500).json({
            ok: false,
            msg: '이벤트 생성 오류가 발생했습니다.'
        });
    }
}

const actualizarEvento = async ( req, res = response ) => {   
    
    const eventoId = req.params.id;
    const uid = req.uid;
    
    try {

        const evento = await Evento.findById( eventoId );

        if ( !evento ) {
            return res.status(404).json({
                ok: false,
                msg: '해당 ID를 가진 이벤트가 존재하지 않습니다.'
            });
        }

        // --- ✨ 권한 확인 로직 시작 ✨ ---
        const isEventOwner = evento.user.toString() === uid;

        if ( !isEventOwner ) {
            const calendarId = evento.calendarId; 
            
            // 🚨 NEW CHECK 1: 캘린더 소유자인지 확인 (A가 B의 이벤트를 수정할 수 있도록 허용)
            const calendar = await CalendarCategory.findById(calendarId);
            const isCalendarOwner = calendar && calendar.user.toString() === uid;

            if (!isCalendarOwner) {
                // 2. 캘린더 소유자도 아닌 경우: 공유받은 편집 권한이 있는지 확인
                const shareEntry = await CalendarShare.findOne({
                    user: uid, // 현재 사용자
                    calendar: calendarId, // 이벤트가 속한 캘린더
                    role: 'editor' // 편집 권한이 있어야 함
                });

                // 3. 소유자(이벤트 or 캘린더)도 아니고, 공유 편집 권한도 없다면 거부
                if (!shareEntry) {
                    return res.status(401).json({
                        ok: false,
                        msg: '이 이벤트를 수정할 권한이 없습니다.'
                    });
                }
            }
        }
        // --- 권한 확인 로직 종료 ---

        const nuevoEvento = {
            ...req.body,
            // 이벤트의 원 소유자 ID(evento.user)를 그대로 유지합니다.
            user: evento.user 
        }

        const eventoActualizado = await Evento.findByIdAndUpdate( eventoId, nuevoEvento, { new: true } );

        res.json({
            ok: true,
            evento: eventoActualizado
        });

        
    } catch (error) {
        console.log(error);
        res.status(500).json({
            ok: false,
            msg: '서버 오류가 발생했습니다. 관리자에게 문의하세요.'
        });
    }

}

const eliminarEvento = async( req, res = response ) => {    
 
    const eventoId = req.params.id;
    const uid = req.uid;

    try {

        const evento = await Evento.findById( eventoId );

        if ( !evento ) {
            return res.status(404).json({
                ok: false,
                msg: '해당 ID를 가진 이벤트가 존재하지 않습니다.'
            });
        }
        
        // --- ✨ 권한 확인 로직 시작 ✨ ---
        const isEventOwner = evento.user.toString() === uid;

        if ( !isEventOwner ) {
            const calendarId = evento.calendarId; 
            
            // 🚨 NEW CHECK 1: 캘린더 소유자인지 확인 (A가 B의 이벤트를 삭제할 수 있도록 허용)
            const calendar = await CalendarCategory.findById(calendarId);
            const isCalendarOwner = calendar && calendar.user.toString() === uid;

            if (!isCalendarOwner) {
                // 2. 캘린더 소유자도 아닌 경우: 공유받은 편집 권한이 있는지 확인
                const shareEntry = await CalendarShare.findOne({
                    user: uid, // 현재 사용자
                    calendar: calendarId, // 이벤트가 속한 캘린더
                    role: 'editor' // 편집 권한이 있어야 함
                });

                // 3. 소유자(이벤트 or 캘린더)도 아니고, 공유 편집 권한도 없다면 거부
                if (!shareEntry) {
                    return res.status(401).json({
                        ok: false,
                        msg: '이 이벤트를 삭제할 권한이 없습니다.'
                    });
                }
            }
        }
        // --- 권한 확인 로직 종료 ---


        await Evento.findByIdAndDelete( eventoId );

        res.json({ ok: true });

        
    } catch (error) {
        console.log(error);
        res.status(500).json({
            ok: false,
            msg: '서버 오류가 발생했습니다. 관리자에게 문의하세요.'
        });
    }
}

module.exports = {
    getEventos,
    crearEvento,
    actualizarEvento,
    eliminarEvento
}
